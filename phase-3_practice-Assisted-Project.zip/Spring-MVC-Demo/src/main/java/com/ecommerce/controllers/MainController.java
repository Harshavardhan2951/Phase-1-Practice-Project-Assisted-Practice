package com.ecommerce.controllers;

import org.springframework.stereotype.Controller;


@Controller
public class MainController {
	
	/*
	 * @GetMapping("/") public String index() { return "index.html"; }
	 */

}