package practice_project;


public class Practice_Project3 {

    public static int exponentialSearch(int[] arr, int target) {
        if (arr[0] == target) {
            return 0; // Target found at the first element
        }

        int n = arr.length;
        int i = 1;

        while (i < n && arr[i] <= target) {
            i *= 2; // Double the position
        }

        int left = i / 2; // Set the left boundary
        int right = Math.min(i, n - 1); // Set the right boundary

        return binarySearch(arr, target, left, right);
    }

    public static int binarySearch(int[] arr, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid; // Found the target, return its index
            }

            if (arr[mid] < target) {
                left = mid + 1; // Target is in the right half
            } else {
                right = mid - 1; // Target is in the left half
            }
        }

        return -1; // Target not found
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int target = 6;

        int index = exponentialSearch(arr, target);
        if (index != -1) {
            System.out.println("Target found at index " + index);
        } else {
            System.out.println("Target not found");
        }
    }
}
