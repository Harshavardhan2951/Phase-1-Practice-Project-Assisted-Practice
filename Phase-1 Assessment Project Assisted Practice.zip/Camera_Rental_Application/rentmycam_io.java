package CAMERA_RENTAL_APPLICATION;


import java.util.ArrayList;
import java.util.Scanner;

/*Constructor Class*/
class Camera {
    private int id;
    private String brand;
    private String model;
    private double price;
    private boolean rented;

    public Camera(int id, String brand, String model, double price) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.rented = false;
    }

    public int getId() {
        return id;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPrice() {
        return price;
    }

    public boolean isRented() {
        return rented;
    }

    public void setRented(boolean rented) {
        this.rented = rented;
    }

    @Override
    public String toString() {
        return id + "\t" + brand + "\t" + model + "\t" + price + "\t" + (rented ? "Rented" : "Available");
    }
}

/*Constructor Wallet*/
class Wallet {
    private double balance;

    public Wallet() {
        this.balance = 50000.0;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void deduct(double amount) {
        balance -= amount;
    }
}

/*Main Class*/
public class rentmycam_io {
    private static ArrayList<Camera> cameraList = new ArrayList<>();
    private static Wallet wallet = new Wallet();
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean loggedIn = login(sc);

        if (loggedIn) {
        	Camera camera1 = new Camera(1, "SAMSUNG","DS123", 500.0);
        	cameraList.add(camera1);
        	Camera camera2 = new Camera(2, "SONY", "HD214", 500.0);
        	cameraList.add(camera2);
        	Camera camera3 = new Camera(3, "PANASONIC", "XC", 500.0);
        	cameraList.add(camera3);
        	Camera camera4 = new Camera(4, "CANON", "XLR", 500.0);
        	cameraList.add(camera4);
        	Camera camera5 = new Camera(5, "FUJITSU", "J5", 500.0);
        	cameraList.add(camera5);
        	Camera camera6 = new Camera(6, "CHROMA", "CT", 500.0);
        	cameraList.add(camera6);
        	Camera camera7 = new Camera(7, "LG", "L123", 500.0);
        	cameraList.add(camera7);
        	Camera camera8 = new Camera(8, "NIKON", "2030", 200);
        	cameraList.add(camera8);
        	Camera camera9 = new Camera(9, "LEICA", "SL2", 3000);
        	cameraList.add(camera9);
        	Camera camera10 = new Camera(10, "OLYMPUS", "E-M10", 5000);
        	cameraList.add(camera10);
            int choice;
            do {
            	System.out.println("\nPLEASE SELECT FROM THE BELOW OPTIONS :-");
            	/*Calling displayMenu();*/
                displayMenu();
                choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {
                    case 1:
                        Camera_Menu(sc);
                        break;
                    case 2:
                        handleRentCameraMenu(sc);
                        break;
                    case 3:
                        displayAllCameras();
                        break;
                    case 4:
                        Wallet_Menu(sc);
                        break;
                    case 5:
                        System.out.println("THANK YOU FOR USING CAMERA RENTAL APPLICATION. WISH YOU A HAPPY DAY.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.\n");
                }
            } while (choice != 5);
        } else {
            System.out.println("Invalid credentials. Access denied.");
        }
    }
    /*login credentials*/
    private static boolean login(Scanner sc) {
    	System.out.println("+**************************************+");
		System.out.println("| WELCOME TO CAMERA RENTAL APPLICATION |");
		System.out.println("+**************************************+\n");			
		System.out.println("Please type username : admin, password : admin123 \n");
        System.out.print("USERNAME: ");
        String username = sc.nextLine();
        System.out.print("PASSWORD: ");
        String password = sc.nextLine();

        return username.equals("admin") && password.equals("admin123");
    }
    /*Display Options*/
    private static void displayMenu() {
        System.out.println("1. MY CAMERA");
        System.out.println("2. RENT A CAMERA");
        System.out.println("3. VIEW ALL CAMERAS");
        System.out.println("4. MY WALLET");
        System.out.println("5. EXIT");
        System.out.print("SELECT YOUR CHOICE FROM THE ABOVE OPTIONS :  ");
    }
    /*Camera Menu*/
    private static void Camera_Menu(Scanner sc) {
        int choice;
        do {
            displayMyCameraMenu();
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    addCamera(sc);
                    break;
                case 2:
                    removeCamera(sc);
                    break;
                case 3:
                    displayMyCameras();
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.\n");
            }
        } while (choice != 4);
    }

    private static void displayMyCameraMenu() {
        System.out.println("\n1. ADD");
        System.out.println("2. REMOVE");
        System.out.println("3. VIEW MY CAMERAS");
        System.out.println("4. GO TO PREVIOUS MENU");
        System.out.print("Enter your choice: ");
    }
    /*Add Camera*/
    private static void addCamera(Scanner sc) {
        System.out.print("\nEnter the camera brand: ");
        String brand = sc.nextLine();
        System.out.print("Enter the model: ");
        String model = sc.nextLine();
        System.out.print("Enter the per day price (INR): ");
        double price = sc.nextDouble();
        sc.nextLine();

        int id = cameraList.size() + 1;
        Camera camera = new Camera(id, brand, model, price);
        cameraList.add(camera);

        System.out.println("\nYour camera has been successfully added to the list.\n");
    }
    /*Remove Camera*/
    private static void removeCamera(Scanner sc) {
        System.out.print("\nEnter the camera ID to remove: ");
        int id = sc.nextInt();
        sc.nextLine();

        boolean found = false;
        for (Camera camera : cameraList) {
            if (camera.getId() == id) {
                cameraList.remove(camera);
                found = true;	
                break;
            }
        }

        if (found) {
            System.out.println("\nCamera successfully removed from the list.\n");
        } else {
            System.out.println("\nCamera with ID " + id + " not found.\n");
        }
    }
    /*Display Camera*/
    private static void displayMyCameras() {
            System.out.println("\nVIEW MY CAMERAS:");
            /*printf is used for distance alignment*/
            System.out.printf("%-4s %-10s %-8s %-15s %s\n", "ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
            for (Camera camera : cameraList) {
                System.out.printf("%-4d %-10s %-8s %-15.2f %s\n", camera.getId(), camera.getBrand(), camera.getModel(), camera.getPrice(), (camera.isRented() ? "Rented" : "Available"));
            }
}

    /*Rent Camera*/
    private static void handleRentCameraMenu(Scanner sc) {
        System.out.println("\nFollowing is the list of available camera(s):\n");
        displayAvailableCameras();

        System.out.print("\nEnter the camera ID you want to rent: ");
        int id = sc.nextInt();
        sc.nextLine();

        boolean found = false;
        for (Camera camera : cameraList) {
            if (camera.getId() == id) {
                found = true;
                if (camera.isRented()) {
                    System.out.println("\nERROR: Camera with ID " + id + " is already rented.\n");
                } else {
                    double rentAmount = camera.getPrice();
                    if (wallet.getBalance() >= rentAmount) {
                        camera.setRented(true);
                        wallet.deduct(rentAmount);
                        System.out.println("\nYour transaction for camera " + camera.getBrand() + " " + camera.getModel() +
                                " with rent INR. " + rentAmount + " has been successfully completed.\n");
                    } else {
                        System.out.println("\nERROR: Transaction failed due to insufficient wallet balance. Please deposit the amount to your wallet.\n");
                    }
                }
                break;
            }
        }

        if (!found) {
            System.out.println("\nCamera with ID " + id + " not found.\n");
        }
    }
    /*Display Camera available to rent*/
    private static void displayAvailableCameras() {
            System.out.printf("%-4s %-10s %-8s %-15s %s\n", "ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
            for (Camera camera : cameraList) {
            	if(!camera.isRented()) {
            		 System.out.printf("%-4d %-10s %-8s %-15.2f %s\n", camera.getId(), camera.getBrand(), camera.getModel(), camera.getPrice(), (camera.isRented() ? "Rented" : "Available"));
            	}
            }System.out.println( );
    }
    /*Display All Cameras*/
    private static void displayAllCameras() {
        System.out.println("\nLIST OF ALL AVAILABLE CAMERAS:");
        System.out.printf("%-4s %-10s %-8s %-15s %s\n", "ID", "BRAND", "MODEL", "PRICE (PER DAY)", "STATUS");
        for (Camera camera : cameraList) {
            System.out.printf("%-4d %-10s %-8s %-15.2f %s\n", camera.getId(), camera.getBrand(), camera.getModel(), camera.getPrice(), (camera.isRented() ? "Rented" : "Available"));
        }
    }
    /*Wallet Menu Method*/
    private static void Wallet_Menu(Scanner sc) {
        System.out.println("\nYOUR CURRENT WALLET BALANCE IS INR. "+"\u20B9 " + wallet.getBalance());

        System.out.print("\nDo you want to deposit more amount to your wallet? (TYPE (1.YES)or(2.NO)): ");
        int choice = sc.nextInt();
        sc.nextLine();

        if (choice == 1) {
            System.out.print("\nEnter the amount to deposit: ");
            double amount = sc.nextDouble();
            sc.nextLine();

            wallet.deposit(amount);
            System.out.println("\nYour wallet balance updated successfully. Current wallet balance" + "\u20B9" + wallet.getBalance()+"\n");
        }
    }
}
